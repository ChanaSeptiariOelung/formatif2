-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 14, 2020 at 06:00 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buku_2018310078`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku_2018310078`
--

CREATE TABLE `buku_2018310078` (
  `kode_buku` varchar(20) NOT NULL,
  `judul` varchar(20) DEFAULT NULL,
  `penulis` varchar(100) DEFAULT NULL,
  `penerbit` varchar(100) DEFAULT NULL,
  `tahun_terbit` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buku_2018310078`
--

INSERT INTO `buku_2018310078` (`kode_buku`, `judul`, `penulis`, `penerbit`, `tahun_terbit`) VALUES
('1', '1234', '1234', '1234', '1234'),
('2', '987', '654', '321', '1975'),
('contoh', '123', '123', '123', '2112'),
('contoh2', '1234', '1234', '1234', '2112');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku_2018310078`
--
ALTER TABLE `buku_2018310078`
  ADD PRIMARY KEY (`kode_buku`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
